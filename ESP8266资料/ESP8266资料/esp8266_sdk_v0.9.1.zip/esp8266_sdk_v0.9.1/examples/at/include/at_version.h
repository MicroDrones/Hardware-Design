#ifndef __AT_VERSION_H__
#define __AT_VERSION_H__

#define AT_VERSION_main   0x00
#define AT_VERSION_sub    0x16

#define AT_VERSION   (AT_VERSION_main << 8 | AT_VERSION_sub)

#endif
